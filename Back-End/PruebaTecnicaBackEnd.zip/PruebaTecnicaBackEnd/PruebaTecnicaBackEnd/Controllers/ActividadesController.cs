﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PruebaTecnicaBackEnd.Data;
using PruebaTecnicaBackEnd.Models;
using System.Text.Json;

namespace PruebaTecnicaBackEnd.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ActividadesController : ControllerBase
    {
        // GET: api/<ActividadesController>}

        public ActividadesDAL _ActividadesDAL = new ActividadesDAL();

        [HttpGet]
        public string Get()
        {
            List<ActividadesModel> ListaActividades = new List<ActividadesModel>();
            ListaActividades = _ActividadesDAL.GetActividades();

            string json = JsonSerializer.Serialize(ListaActividades);

            return json;
        }

    }
}
