﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PruebaTecnicaBackEnd.Data;
using PruebaTecnicaBackEnd.Models;
using System.Text.Json;

namespace PruebaTecnicaBackEnd.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UsuariosController : ControllerBase
    {

        public UsuariosDAL _UsuariosDAL = new UsuariosDAL();

        // GET: api/<UsuariosController>
        [HttpGet]
        public string Get()
        {
            List<UsuariosModel> ListaUsuarios = new List<UsuariosModel>();
            ListaUsuarios = _UsuariosDAL.GetUsuarios();

            string json = JsonSerializer.Serialize(ListaUsuarios);

            return json;
        }

        // POST api/<UsuariosController>
        [HttpPost]
        public string Post([FromBody] UsuariosModel Usuario)
        {

            ActividadesDAL _ActividadesDAL = new ActividadesDAL();
            ActividadesModel Actividad = new ActividadesModel();
            Boolean Respuesta = _UsuariosDAL.InsertUsuario(Usuario);

            if (Respuesta)
            {
                Actividad.Create_date = DateTime.Now;
                Actividad.Actividad = "Creación de Usuario";
                Respuesta = _ActividadesDAL.InsertActividad(Actividad);
            }

            if (Respuesta)
            {
                return JsonSerializer.Serialize(new
                {
                    respuesta = "Insertado",
                    success = true
                });
            }
            else
            {
                return JsonSerializer.Serialize(new
                {
                    respuesta = "Error",
                    success = false
                });
            }

        }

    }
}
