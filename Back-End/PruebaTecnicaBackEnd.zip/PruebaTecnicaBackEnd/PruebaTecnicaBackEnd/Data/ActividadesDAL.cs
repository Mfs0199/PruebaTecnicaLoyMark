﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Data.SqlClient;
using PruebaTecnicaBackEnd.Models;
using System.Data;

namespace PruebaTecnicaBackEnd.Data
{
    public class ActividadesDAL
    {

        public string cnn = "";

        public ActividadesDAL()
        {
            var builder = new ConfigurationBuilder().SetBasePath(
                Directory.GetCurrentDirectory()).
                AddJsonFile("appsettings.json").Build();

            cnn = builder.GetSection("ConnectionStrings:DefaultConnection").Value;
        }

        public List<ActividadesModel> GetActividades()
        {

            try
            {

                List<ActividadesModel> ListaActividades = new List<ActividadesModel>();

                using (SqlConnection cn = new SqlConnection(cnn))
                {

                    using (SqlCommand cmd = new SqlCommand("SELECT ACTIVIDADES.Id_actividad, ACTIVIDADES.Create_date, ACTIVIDADES.Id_usuario, ACTIVIDADES.Actividad, CONCAT(USUARIOS.Nombre,' ',USUARIOS.Apellido) NombreCompleto FROM ACTIVIDADES " +
                        "INNER JOIN USUARIOS ON USUARIOS.Id_usuario = ACTIVIDADES.Id_usuario " +
                        "ORDER BY ACTIVIDADES.Create_date DESC", cn))
                    {

                        if (cn.State == System.Data.ConnectionState.Closed)
                            cn.Open();

                        IDataReader reader = cmd.ExecuteReader();

                        while (reader.Read())
                        {

                            ListaActividades.Add(new ActividadesModel()
                            {
                                Id_actividad = int.Parse(reader["Id_actividad"].ToString()),
                                Create_date = Convert.ToDateTime(reader["Create_date"].ToString()),
                                Id_usuario = int.Parse(reader["Id_usuario"].ToString()),
                                Actividad = reader["Actividad"].ToString(),
                                NombreCompleto = reader["NombreCompleto"].ToString()
                            });

                        }

                        return ListaActividades;

                    }

                }

            }

            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return null;
            }

        }

        public Boolean InsertActividad(ActividadesModel Actividad)
        {

            try
            {

                using (SqlConnection cn = new SqlConnection(cnn))
                {

                    using (SqlCommand cmd = new SqlCommand("INSERT INTO ACTIVIDADES (Create_date,Id_usuario,Actividad)" +
                        "VALUES ('" + Actividad.Create_date.ToString("yyyy-MM-dd HH:mm:ss") + "',(SELECT MAX(Id_usuario) FROM USUARIOS),'" + Actividad.Actividad + "')" , cn))
                    {

                        if (cn.State == System.Data.ConnectionState.Closed)
                            cn.Open();

                        int result = cmd.ExecuteNonQuery();

                        if (result < 0)
                        {
                            return false;
                        }
                        else
                        {
                            return true;
                        }
                    }

                }

            }

            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return false;
            }

        }
    }
}
