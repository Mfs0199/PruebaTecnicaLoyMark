﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Data.SqlClient;
using PruebaTecnicaBackEnd.Models;
using System.Data;

namespace PruebaTecnicaBackEnd.Data
{
    public class UsuariosDAL
    {
        public string cnn = "";

        public UsuariosDAL()
        {
            var builder = new ConfigurationBuilder().SetBasePath(
                Directory.GetCurrentDirectory()).
                AddJsonFile("appsettings.json").Build();

            cnn = builder.GetSection("ConnectionStrings:DefaultConnection").Value;
        }

        public List<UsuariosModel> GetUsuarios()
        {

            try
            {

                List<UsuariosModel> ListaUsuarios = new List<UsuariosModel>();

                using (SqlConnection cn = new SqlConnection(cnn))
                {

                    using (SqlCommand cmd = new SqlCommand("SELECT * FROM USUARIOS", cn))
                    {

                        if (cn.State == System.Data.ConnectionState.Closed)
                            cn.Open();

                        IDataReader reader = cmd.ExecuteReader();

                        while (reader.Read())
                        {

                            ListaUsuarios.Add(new UsuariosModel()
                            {
                                Id_usuario = int.Parse(reader["Id_usuario"].ToString()),
                                Nombre = reader["Nombre"].ToString(),
                                Apellido = reader["Apellido"].ToString(),
                                CorreoElectronico = reader["CorreoElectronico"].ToString(),
                                FechadeNacimiento = Convert.ToDateTime(reader["FechadeNacimiento"].ToString()),
                                Telefono = int.Parse(reader["Telefono"].ToString()),
                                PaisdeResidencia = reader["PaisdeResidencia"].ToString(),
                                Pregunta = Convert.ToBoolean(reader["Pregunta"].ToString())
                            });

                        }

                        return ListaUsuarios;

                    }

                }

            }

            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return null;
            }

        }

        public Boolean InsertUsuario(UsuariosModel Usuario)
        {

            try {

                using (SqlConnection cn = new SqlConnection(cnn))
                {

                    using (SqlCommand cmd = new SqlCommand("INSERT INTO USUARIOS (Nombre,Apellido,CorreoElectronico,FechadeNacimiento," +
                        "Telefono,PaisdeResidencia,Pregunta) VALUES ('" + Usuario.Nombre + "','" + Usuario.Apellido + "','" + Usuario.CorreoElectronico + "','" + Usuario.FechadeNacimiento.ToString("yyyy-MM-dd") + "'," +
                        "'" + Usuario.Telefono + "','" + Usuario.PaisdeResidencia + "','" + Usuario.PreguntaInt + "')", cn))
                    {

                        if (cn.State == System.Data.ConnectionState.Closed)
                            cn.Open();

                        int result = cmd.ExecuteNonQuery();

                        if (result < 0)
                        {
                            return false;
                        }
                        else
                        {
                            return true;
                        }
                    }

                }

            }

            catch (Exception ex)
            {
                Console.WriteLine(ex);
                return false;
            }

        }
    }
}
