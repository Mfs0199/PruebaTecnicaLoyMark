﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PruebaTecnicaBackEnd.Models
{
    public class ActividadesModel
    {
        public int Id_actividad { set; get; }
        public DateTime Create_date { set; get; }
        public int Id_usuario { set; get; }
        public string Actividad { set; get; }
        public string NombreCompleto { set; get; }

    }
}
