﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PruebaTecnicaBackEnd.Models
{
    public class UsuariosModel
    {
        public int Id_usuario { set; get; }
        public string Nombre { set; get; }
        public string Apellido { set; get; }
        public string CorreoElectronico { set; get; }
        public DateTime FechadeNacimiento { set; get; }
        public int Telefono { set; get; }
        public string PaisdeResidencia { set; get; }
        public Boolean Pregunta { set; get; }

        public int PreguntaInt { 
            get {
                if (this.Pregunta)
                {
                    return 1;
                }
                else
                {
                    return 0;
                }
            } 
        }

        public string PreguntaStr
        {
            get
            {
                if (this.Pregunta)
                {
                    return "Si";
                }
                else
                {
                    return "No";
                }
            }
        }

    }
}
