﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PruebaTecnicaFrontEnd.Models
{
    public class UsuariosModel
    {
        [Required (ErrorMessage = "Este campo es requerido")]
        [Display (Name = "Nombre:")]
        [RegularExpression("[^0-9]*", ErrorMessage = "El texto no puede contener numeros")]
        public string Nombre { set; get; }

        [Required(ErrorMessage = "Este campo es requerido")]
        [Display(Name = "Apellido:")]
        [RegularExpression("[^0-9]*", ErrorMessage = "El texto no puede contener numeros")]
        public string Apellido { set; get; }

        [Required(ErrorMessage = "Este campo es requerido")]
        [Display(Name = "Correo Electrónico:")]
        [DataType (DataType.EmailAddress)]
        [EmailAddress]
        public string CorreoElectronico { set; get; }

        [Required(ErrorMessage = "Este campo es requerido")]
        [Display(Name = "Fecha de Nacimiento:")]
        public DateTime FechadeNacimiento { set; get; }

        [Required(ErrorMessage = "Este campo es requerido")]
        [Display(Name = "Teléfono:")]
        [RegularExpression("([0-9]+)", ErrorMessage = "Solo puede ingresar numeros")]
        public int Telefono { set; get; }

        [Required(ErrorMessage = "Este campo es requerido")]
        [Display(Name = "País de Residencia:")]
        public string PaisdeResidencia { set; get; }

        [Required(ErrorMessage = "Este campo es requerido")]
        [Display(Name = "¿Desea recibir información?:")]
        public Boolean Pregunta { set; get; }
    }
}
