﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PruebaTecnicaFrontEnd.Models;

namespace PruebaTecnicaFrontEnd.Controllers
{
    public class ActividadesController : Controller
    {
        // GET: ActividadesController
        public ActionResult Index()
        {
            return View();
        }

    }
}
