﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PruebaTecnicaFrontEnd.Models;
using System.Net;
using System.IO;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace PruebaTecnicaFrontEnd.Controllers
{
    public class UsuariosController : Controller
    {
        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public ActionResult Agregar()
        {
            List<SelectListItem> listaPaises = new List<SelectListItem>();

            listaPaises.Add(new SelectListItem()
            { Value = "CRI", Text = "Costa Rica"});

            listaPaises.Add(new SelectListItem()
            { Value = "PAN", Text = "Panama" });

            ViewBag.listaPaises = listaPaises;

            List<SelectListItem> listaPregunta = new List<SelectListItem>();

            listaPregunta.Add(new SelectListItem()
            { Value = "false", Text = "No" });

            listaPregunta.Add(new SelectListItem()
            { Value = "true", Text = "Si" });

            ViewBag.listaPregunta = listaPregunta;

            return View();
        }

        [HttpPost]
        public ActionResult Agregar(UsuariosModel m)
        {
            try
            {

                List<SelectListItem> listaPaises = new List<SelectListItem>();

                listaPaises.Add(new SelectListItem()
                { Value = "CRI", Text = "Costa Rica" });

                listaPaises.Add(new SelectListItem()
                { Value = "PAN", Text = "Panama" });

                ViewBag.listaPaises = listaPaises;

                List<SelectListItem> listaPregunta = new List<SelectListItem>();

                listaPregunta.Add(new SelectListItem()
                { Value = "false", Text = "No" });

                listaPregunta.Add(new SelectListItem()
                { Value = "true", Text = "Si" });

                ViewBag.listaPregunta = listaPregunta;

                if (!ModelState.IsValid)
                {
                    return View(m);
                }

                var url = $"http://localhost:47049/api/Usuarios/";
                var request = (HttpWebRequest)WebRequest.Create(url);
                string json = JsonConvert.SerializeObject(m);
                request.Method = "POST";
                request.ContentType = "application/json";
                request.Accept = "application/json";
                using (var streamWriter = new StreamWriter(request.GetRequestStream()))
                {
                    streamWriter.Write(json);
                    streamWriter.Flush();
                    streamWriter.Close();
                }

                using (WebResponse response = request.GetResponse())
                {
                    using (Stream strReader = response.GetResponseStream())
                    {
                        if (strReader == null) return View(m);
                        using (StreamReader objReader = new StreamReader(strReader))
                        {
                            string responseBody = objReader.ReadToEnd();
                            Console.WriteLine(responseBody);

                            return View("Index");
                        }
                    }
                }


            }
            catch (Exception ex)
            {
                return View(m);
            }

        }
    }
}
